<?php
// Este arquivo vazio impede listagem direta do diretório
header("Location: ../index.php");
exit;
